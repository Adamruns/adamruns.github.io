import pytest

from sympy import Mul
from sympy.physics.quantum import Dagger, IdentityOperator, Operator


@pytest.mark.parametrize('dimension', [None, 2])
def test_dagger_operator_times_identity(dimension):
    identity = (IdentityOperator() if dimension is None
                else IdentityOperator(dimension))
    operator = Operator('A')
    dagger = Dagger(operator)

    assert dagger * identity == dagger
    assert operator * identity == operator
    assert identity * operator == operator


def test_dagger_operator_other_products():
    operator = Operator('A')
    other = Operator('B')
    dagger = Dagger(operator)

    assert dagger * other == Mul(dagger, other)
    assert dagger * other != other * dagger
    assert dagger * 2 == 2 * dagger
    assert dagger * 0 == 0
    assert dagger * 1 == dagger
