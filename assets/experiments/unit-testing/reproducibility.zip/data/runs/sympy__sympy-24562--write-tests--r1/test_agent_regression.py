import pytest

from sympy import Rational, S


@pytest.mark.parametrize('numerator', ['0.5', 0.5, Rational(1, 2)])
@pytest.mark.parametrize('denominator', ['100', 100, '100.0'])
def test_rational_two_argument_input_types(numerator, denominator):
    assert Rational(numerator, denominator) == Rational(1, 200)


@pytest.mark.parametrize('numerator, denominator, expected', [
    ('1/2', '3/4', Rational(2, 3)),
    ('0.5', '-100', Rational(-1, 200)),
    ('1e-2', '2e-2', S.Half),
    ('0.0', '100', S.Zero),
    ('0.5', '0', S.ComplexInfinity),
    ('0', '0', S.NaN),
])
def test_rational_string_quotients(numerator, denominator, expected):
    assert Rational(numerator, denominator) == expected
