import pytest

from sympy import ZZ, ring, symbols


def test_as_expr_uses_supplied_symbols():
    R, x, y, z = ring("x,y,z", ZZ)
    f = 3*x**2*y - x*y*z + 7*z**3 + 1
    u, v, w = symbols("u,v,w")

    assert f.as_expr(u, v, w) == 3*u**2*v - u*v*w + 7*w**3 + 1
    X, Y, Z = R.symbols
    assert f.as_expr(Z, X, Y) == 3*Z**2*X - Z*X*Y + 7*Y**3 + 1
    assert f.as_expr() == 3*X**2*Y - X*Y*Z + 7*Z**3 + 1

    for replacements in ((u,), (u, v), (u, v, w, X)):
        with pytest.raises(ValueError):
            f.as_expr(*replacements)


def test_as_expr_constants_and_zero():
    R, x = ring("x", ZZ)
    u = symbols("u")
    assert x.as_expr(u) == u
    assert R.zero.as_expr(u) == 0
    assert R(3).as_expr(u) == 3

    constants, = ring("", ZZ)
    assert constants(3).as_expr() == 3
