import pytest

from sympy import Mod, lambdify, symbols


@pytest.mark.parametrize('values', [(3, 7, 2), (-3, 7, 2), (3, -7, -2)])
def test_lambdify_mod_operator_precedence(values):
    x, y, z = symbols('x y z')
    remainder = Mod(x, y)
    expressions = [
        -remainder,
        2*remainder,
        z*remainder,
        -z*remainder,
        remainder**2,
        1/remainder,
        Mod(z, remainder, evaluate=False),
        Mod(remainder, z, evaluate=False),
        Mod(x + z, y + z),
        remainder + z,
    ]
    substitutions = dict(zip((x, y, z), values))
    for expression in expressions:
        function = lambdify((x, y, z), expression, modules=[])
        expected = float(expression.subs(substitutions))
        assert function(*values) == pytest.approx(expected), str(expression)


def test_lambdify_negated_mod_reported_example():
    x, y = symbols('x y')
    function = lambdify((x, y), -Mod(x, y), modules=[])
    assert function(3, 7) == -3
