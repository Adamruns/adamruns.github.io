import pytest

from sympy import Mul
from sympy.physics.quantum import Dagger, IdentityOperator, Operator


@pytest.mark.parametrize('identity', [IdentityOperator(), IdentityOperator(2)])
def test_dagger_operator_times_identity(identity):
    operator = Operator('A')
    dagger = Dagger(operator)

    assert dagger * identity == dagger
    assert operator * identity == operator
    assert identity * operator == operator


def test_dagger_multiplication_preserves_other_products():
    dagger = Dagger(Operator('A'))
    operator = Operator('B')

    assert dagger * operator == Mul(dagger, operator)
    assert dagger * operator != operator * dagger
    assert dagger * 2 == 2 * dagger
    assert dagger * 0 == 0
