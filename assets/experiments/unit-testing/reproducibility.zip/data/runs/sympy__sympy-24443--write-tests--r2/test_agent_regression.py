import pytest

from sympy.combinatorics import DihedralGroup
from sympy.combinatorics.homomorphisms import homomorphism


def test_dihedral_identity_homomorphism():
    group = DihedralGroup(3)
    mapping = homomorphism(group, group, group.generators, group.generators)

    for element in group.generate_schreier_sims():
        assert mapping(element) == element
    assert mapping.is_isomorphism()


def test_dihedral_automorphism_with_inverse_generator():
    group = DihedralGroup(3)
    rotation, reflection = group.generators
    mapping = homomorphism(group, group, group.generators,
                           [rotation**-1, reflection])

    elements = list(group.generate_schreier_sims())
    assert mapping(rotation) == rotation**-1
    assert mapping(reflection) == reflection
    for left in elements:
        for right in elements:
            assert mapping(left*right) == mapping(left)*mapping(right)


def test_invalid_dihedral_generator_images_are_rejected():
    group = DihedralGroup(3)
    rotation, reflection = group.generators
    with pytest.raises(ValueError, match="do not define a homomorphism"):
        homomorphism(group, group, group.generators, [reflection, rotation])
