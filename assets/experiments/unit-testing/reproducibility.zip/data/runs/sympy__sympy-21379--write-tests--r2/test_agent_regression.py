import pytest

from sympy import Float, Mod, Piecewise, cosh, exp, sinh, symbols, tanh
from sympy.core.cache import clear_cache


@pytest.mark.parametrize("hyperbolic", [sinh, cosh, tanh])
@pytest.mark.parametrize("real", [True, False])
def test_subs_piecewise_hyperbolic(hyperbolic, real):
    clear_cache()
    assumptions = {"real": True} if real else {}
    x, y, z = symbols("x y z", **assumptions)
    piece = Piecewise((x, y > x), (y, True))
    expr = exp(hyperbolic(piece / z))

    result = expr.subs({1: 1.0})

    assert result == exp(hyperbolic(piece / z**Float(1)))
    assert expr.subs({1: 1.0}) == result
    assert result.subs({x: 2, y: 3, z: 1}) == exp(hyperbolic(2))


def test_mod_piecewise_operands():
    x, y = symbols("x y", real=True)
    piece = Piecewise((x, x > 0), (y, True))

    dividend = Mod(piece, 3)
    divisor = Mod(x, piece)

    assert dividend == Mod(piece, 3, evaluate=False)
    assert divisor == Mod(x, piece, evaluate=False)
    assert dividend.subs({x: 5, y: 2}) == 2
    assert dividend.subs({x: -5, y: 2}) == 2
    assert divisor.subs({x: -5, y: 3}) == 1
