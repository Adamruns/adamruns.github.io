import pytest

from sympy import Pow, Rational, Symbol, latex
from sympy.physics.secondquant import B, Bd, F, Fd, Commutator


def test_creation_operator_power_in_commutator():
    state = Symbol('0')
    assert latex(Commutator(Bd(state)**2, B(state))) == (
        r'- \left[b_{0},{b^\dagger_{0}}^{2}\right]'
    )


@pytest.mark.parametrize('creator,annihilator,letter', [(Bd, B, 'b'), (Fd, F, 'a')])
def test_creation_operator_power_grouping(creator, annihilator, letter):
    state = Symbol('i')
    operator = creator(state)
    bare = letter + r'^\dagger_{i}'
    assert latex(operator) == bare
    for exponent in (2, -1, Symbol('n')):
        assert latex(Pow(operator, exponent, evaluate=False)) == (
            '{' + bare + '}^{' + latex(exponent) + '}'
        )
    assert latex(operator**Rational(2, 3), fold_frac_powers=True) == (
        '{' + bare + '}^{2/3}'
    )
    assert latex(operator**Rational(1, 2)) == r'\sqrt{' + bare + '}'
    assert latex(annihilator(state)**2) == letter + r'_{i}^{2}'
