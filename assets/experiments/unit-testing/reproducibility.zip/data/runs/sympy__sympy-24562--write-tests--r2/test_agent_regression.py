import pytest

from sympy import Rational


@pytest.mark.parametrize(
    "numerator, denominator, expected",
    [
        ('0.5', '100', Rational(1, 200)),
        (0.5, '100', Rational(1, 200)),
        (Rational(1, 2), '100', Rational(1, 200)),
        ('0.5', '0.25', Rational(2)),
        ('1/2', '3/4', Rational(2, 3)),
        ('0.5', '-100', Rational(-1, 200)),
        ('0.5', '1e2', Rational(1, 200)),
        ('0.5', 100, Rational(1, 200)),
        (0.5, 100, Rational(1, 200)),
        (1, '100', Rational(1, 100)),
    ],
)
def test_rational_two_argument_string_inputs(numerator, denominator, expected):
    assert Rational(numerator, denominator) == expected
