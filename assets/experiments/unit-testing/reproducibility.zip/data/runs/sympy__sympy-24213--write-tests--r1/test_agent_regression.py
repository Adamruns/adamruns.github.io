import pytest

from sympy.physics import units
from sympy.physics.units.systems.si import SI


def test_add_equivalent_derived_dimensions():
    velocity = units.Quantity('regression_velocity')
    acceleration = units.Quantity('regression_acceleration')
    duration = units.Quantity('regression_duration')
    SI.set_quantity_dimension(velocity, units.velocity)
    SI.set_quantity_scale_factor(velocity, 2 * units.meter / units.second)
    SI.set_quantity_dimension(acceleration, units.acceleration)
    SI.set_quantity_scale_factor(
        acceleration, -9.8 * units.meter / units.second**2)
    SI.set_quantity_dimension(duration, units.time)
    SI.set_quantity_scale_factor(duration, 5 * units.second)

    expr = acceleration * duration + velocity
    factor, dimension = SI._collect_factor_and_dimension(expr)

    assert float(factor) == pytest.approx(-47)
    assert SI.get_dimension_system().equivalent_dims(dimension, units.velocity)
    assert dimension == SI._collect_factor_and_dimension(expr.args[0])[1]


def test_add_incompatible_dimensions_still_rejected():
    with pytest.raises(ValueError, match='Dimension of'):
        SI._collect_factor_and_dimension(units.meter + units.second)


def test_add_identical_dimensions_preserves_scale():
    assert SI._collect_factor_and_dimension(
        units.meter + units.centimeter) == (units.centimeter.scale_factor + 1,
                                          units.length)
