import pytest

from sympy import And, Contains, FiniteSet, I, Interval, Piecewise, S, Symbol
from sympy.sets.sets import Set


def test_contains_as_set_returns_real_solution_set():
    x = Symbol('x')
    for domain, expected in [
        (S.Reals, S.Reals),
        (S.Integers, S.Integers),
        (Interval(0, 1), Interval(0, 1)),
        (S.Complexes, S.Reals),
        (FiniteSet(1, I), FiniteSet(1)),
    ]:
        result = Contains(x, domain).as_set()
        assert isinstance(result, Set)
        assert result == expected
    assert Contains(x, S.Reals).as_set().as_relational(x) == And(
        -S.Infinity < x, x < S.Infinity)


def test_contains_as_set_in_boolean_and_piecewise():
    x = Symbol('x')
    assert And(Contains(x, S.Reals), x > 0).as_set() == Interval.open(0, S.Infinity)
    piecewise = Piecewise((6, Contains(x, S.Reals)), (7, True))
    assert piecewise.subs(x, 0) == 6
    assert piecewise.subs(x, I) == 7
    assert piecewise.as_expr_set_pairs() == [(6, S.Reals)]


def test_contains_as_set_preserves_unsupported_cases():
    x, y = Symbol('x'), Symbol('y')
    with pytest.raises(NotImplementedError):
        Contains(x, FiniteSet(y)).as_set()
    with pytest.raises(NotImplementedError):
        Contains(x**2, S.Integers).as_set()
