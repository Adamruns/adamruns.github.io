import pytest

from sympy import Abs, exp
from sympy.physics.units import Dimension, farad, meter, ohm, second
from sympy.physics.units.systems.si import SI


@pytest.mark.parametrize("scale", [1, 2])
def test_exponential_of_dimensionless_derived_unit_ratio(scale):
    argument = scale * second / (ohm * farad)
    _, dimension = SI._collect_factor_and_dimension(argument)
    assert SI.get_dimension_system().is_dimensionless(dimension)

    assert SI._collect_factor_and_dimension(100 + exp(argument)) == (
        100 + exp(scale), Dimension(1))
    assert SI._collect_factor_and_dimension(exp(argument)) == (
        exp(scale), Dimension(1))


def test_dimensionful_function_behavior_is_preserved():
    assert SI._collect_factor_and_dimension(Abs(-2 * meter)) == (
        2, meter.dimension)
    with pytest.raises(ValueError, match="Dimension of"):
        SI._collect_factor_and_dimension(100 + exp(second))
