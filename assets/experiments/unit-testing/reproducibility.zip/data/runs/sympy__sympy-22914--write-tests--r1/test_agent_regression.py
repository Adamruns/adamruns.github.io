import pytest

from sympy import Max, Min, pycode, symbols
from sympy.printing.pycode import PythonCodePrinter


@pytest.mark.parametrize('function, name', [(Min, 'min'), (Max, 'max')])
def test_python_min_max(function, name):
    a, b, c = symbols('a b c')
    assert pycode(function(a, b)) == '{}(a, b)'.format(name)
    printer = PythonCodePrinter()
    code = printer.doprint(function(a, b, c))
    assert code == '{}(a, b, c)'.format(name)
    assert not printer.module_imports
    for values in [(-3, 2, 7), (5, 5, -1)]:
        expected = min(values) if function is Min else max(values)
        assert eval(code, dict(zip(('a', 'b', 'c'), values))) == expected


def test_python_nested_min_max():
    a, b, c = symbols('a b c')
    expr = Min(a + 1, Max(b, c**2))
    code = pycode(expr)
    for values in [(4, -2, 3), (-5, 7, 2)]:
        bindings = dict(zip(('a', 'b', 'c'), values))
        assert eval(code, bindings) == expr.subs(dict(zip((a, b, c), values)))
