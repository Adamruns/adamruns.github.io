import pytest

from sympy import Matrix, zeros
from sympy.matrices.normalforms import hermite_normal_form


def test_row_style_hnf_preserves_independent_rows():
    matrix = Matrix([[5, 8, 12], [0, 0, 1]])
    # Reversing both axes is equivalent to numpy.flip without an axis.
    flipped = matrix[::-1, ::-1]
    result = hermite_normal_form(flipped.T).T[::-1, ::-1]
    assert result == Matrix([[5, 8, 0], [0, 0, 1]])
    assert result.rank() == matrix.rank()


@pytest.mark.parametrize("matrix, expected", [
    (Matrix([[2, 7], [0, 0], [0, 0]]), Matrix([[1], [0], [0]])),
    (Matrix([[3], [0], [0]]), Matrix([[3], [0], [0]])),
    (Matrix([[1, 0], [0, 1], [0, 0]]),
     Matrix([[1, 0], [0, 1], [0, 0]])),
    (zeros(3, 2), zeros(3, 0)),
    (zeros(3, 0), zeros(3, 0)),
    (zeros(0, 3), zeros(0, 0)),
])
def test_hnf_handles_skipped_pivots_and_empty_matrices(matrix, expected):
    result = hermite_normal_form(matrix)
    assert result == expected
    assert result.cols == matrix.rank()
