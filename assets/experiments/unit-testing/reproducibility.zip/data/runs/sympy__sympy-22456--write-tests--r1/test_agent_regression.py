import pytest

from sympy import Basic, Symbol, Tuple
from sympy.codegen.ast import Comment, QuotedString, String


@pytest.mark.parametrize('cls', [String, QuotedString, Comment])
@pytest.mark.parametrize('text', ['', 'foo', 'x + 1', 'quotes\'"\nλ'])
def test_string_argument_reconstruction(cls, text):
    expr = cls(text)
    rebuilt = expr.func(*expr.args)
    assert rebuilt == expr
    assert type(rebuilt) is cls
    assert rebuilt.text == text
    assert isinstance(rebuilt.text, str)
    assert hash(rebuilt) == hash(expr)
    assert all(isinstance(arg, Basic) for arg in expr.args)
    assert expr.func(**expr.kwargs()) == expr
    assert cls(expr) is expr
    assert expr.is_Atom
    assert expr.atoms() == {expr}
    assert Tuple(expr).atoms() == {expr}
    assert expr.free_symbols == set()
    assert expr.subs(Symbol('x'), 1) == expr
    assert expr.xreplace({Symbol('x'): 1}) == expr


def test_string_display_and_validation():
    expr = String('foo')
    assert str(expr) == 'foo'
    assert repr(expr) == "String('foo')"
    assert expr.kwargs() == {'text': 'foo'}
    with pytest.raises(TypeError):
        String(123)
