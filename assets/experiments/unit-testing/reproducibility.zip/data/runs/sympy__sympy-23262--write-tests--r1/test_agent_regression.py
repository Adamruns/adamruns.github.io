import inspect

import pytest

from sympy import lambdify, symbols
from sympy.utilities.lambdify import lambdastr


@pytest.mark.parametrize("expr", [(1,), (), (1, 2), ((1,),), [(1,)], ([1],)])
def test_lambdify_preserves_tuple_structure(expr):
    function = lambdify([], expr, modules="math")
    assert function() == expr
    assert type(function()) is type(expr)
    assert eval(lambdastr([], expr))() == expr


def test_lambdify_singleton_tuple_source():
    function = lambdify([], (1,))
    assert "return (1,)" in inspect.getsource(function)
    assert function() == (1,)


def test_lambdify_symbolic_singleton_tuple():
    x = symbols("x")
    function = lambdify(x, (x + 1,), modules="math")
    assert function(2) == (3,)
