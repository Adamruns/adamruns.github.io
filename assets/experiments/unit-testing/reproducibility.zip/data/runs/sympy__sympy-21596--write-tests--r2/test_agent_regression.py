from sympy import FiniteSet, I, ImageSet, Lambda, S, symbols


def test_imageset_real_intersection_keeps_zero_imaginary_part():
    n = symbols('n')
    source = ImageSet(Lambda(n, n + (n - 1)*(n + 1)*I), S.Integers)
    result = source.intersect(S.Reals)
    assert 2 not in source
    assert 2 not in result
    assert result == FiniteSet(-1, 1)


def test_imageset_real_intersection_respects_parameter_domain():
    n = symbols('n')
    expression = n + (n - 1)*(n + 1)*I
    assert ImageSet(Lambda(n, expression), S.Naturals).intersect(S.Reals) == FiniteSet(1)
    expression = n + (2*n - 1)*I
    assert ImageSet(Lambda(n, expression), S.Integers).intersect(S.Reals) == S.EmptySet
    assert ImageSet(Lambda(n, expression), S.Reals).intersect(S.Reals) == FiniteSet(S.Half)


def test_imageset_real_intersection_nonlinear_condition():
    n = symbols('n')
    source = ImageSet(Lambda(n, n + (n**2 - 2)*I), S.Reals)
    result = source.intersect(S.Reals)
    assert S(2)**S.Half in result
    assert 2 not in result


def test_imageset_real_intersection_existing_cases():
    n = symbols('n')
    assert ImageSet(Lambda(n, 2*n), S.Integers).intersect(S.Reals) == ImageSet(Lambda(n, 2*n), S.Integers)
    assert ImageSet(Lambda(n, n + I), S.Integers).intersect(S.Reals) == S.EmptySet
