import pickle

import pytest

from sympy import Basic, Symbol
from sympy.codegen.ast import Comment, QuotedString, String


@pytest.mark.parametrize("cls", [String, QuotedString, Comment])
@pytest.mark.parametrize("text", ["", "foobar", "x + y", "quotes ' and \"\n\u03bb"])
def test_string_argument_reconstruction(cls, text):
    expr = cls(text)

    assert expr.func(*expr.args) == expr
    assert all(isinstance(arg, Basic) for arg in expr.args)
    assert expr.func(**expr.kwargs()) == expr
    assert expr.text == text
    assert str(expr) == text
    assert expr.is_Atom
    assert expr.atoms() == {expr}
    assert expr.atoms(cls) == {expr}
    assert expr.free_symbols == set()
    assert expr.subs(Symbol("x"), 1) == expr
    assert expr.xreplace({Symbol("x"): 1}) == expr
    assert pickle.loads(pickle.dumps(expr)) == expr
