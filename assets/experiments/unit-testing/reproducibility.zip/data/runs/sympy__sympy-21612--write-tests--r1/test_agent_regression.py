import pytest

from sympy import Mul, Pow, S, simplify, symbols, sympify


def test_nested_fraction_denominator_grouping():
    a, b, c = symbols('a b c')
    # The unevaluated expression constructed by convert_frac for the report.
    numerator = Mul(a**3 + b, Pow(c, -1, evaluate=False), evaluate=False)
    denominator = Pow(Pow(c, 2, evaluate=False), -1, evaluate=False)
    expr = Mul(numerator, Pow(denominator, -1, evaluate=False), evaluate=False)

    assert str(expr) == '((a**3 + b)/c)/(1/(c**2))'
    assert simplify(sympify(str(expr)) - expr) == 0
    assert sympify(str(expr)).subs({a: 2, b: 3, c: 2}) == 22


@pytest.mark.parametrize('exponent', [-1, -S.Half])
def test_reciprocal_denominator_roundtrip(exponent):
    a, c = symbols('a c')
    denominator = Pow(c, exponent, evaluate=False)
    expr = Mul(a, Pow(denominator, -1, evaluate=False), evaluate=False)
    assert simplify(sympify(str(expr)) - expr) == 0


def test_latex_nested_fraction_denominator_grouping():
    pytest.importorskip('antlr4')
    from sympy.parsing.latex import parse_latex

    expr = parse_latex(r'\frac{\frac{a^3+b}{c}}{\frac{1}{c^2}}')
    assert str(expr) == '((a**3 + b)/c)/(1/(c**2))'
    assert simplify(sympify(str(expr)) - expr) == 0
