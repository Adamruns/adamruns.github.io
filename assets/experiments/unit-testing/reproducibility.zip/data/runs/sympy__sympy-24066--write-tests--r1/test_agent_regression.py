import pytest

from sympy import E, exp, sin
from sympy.physics.units import Dimension, farad, meter, ohm, second
from sympy.physics.units.systems.si import SI


@pytest.mark.parametrize('function', [exp, sin])
@pytest.mark.parametrize('scale', [1, 2])
def test_function_of_derived_dimensionless_argument(function, scale):
    argument = scale * second / (ohm * farad)
    factor, dimension = SI._collect_factor_and_dimension(argument)
    assert factor == scale
    assert SI.get_dimension_system().is_dimensionless(dimension)
    assert SI._collect_factor_and_dimension(function(argument)) == (
        function(scale), Dimension(1))
    assert SI._collect_factor_and_dimension(100 + function(argument)) == (
        100 + function(scale), Dimension(1))


def test_dimensionful_function_argument_preserves_existing_behavior():
    assert SI._collect_factor_and_dimension(exp(meter)) == (E, meter.dimension)
    with pytest.raises(ValueError, match='Dimension of'):
        SI._collect_factor_and_dimension(100 + exp(meter))
