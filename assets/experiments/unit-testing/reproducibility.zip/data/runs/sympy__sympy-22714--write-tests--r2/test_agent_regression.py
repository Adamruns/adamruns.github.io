import pytest
import sympy as sp


def test_sympify_point_with_evaluation_disabled():
    expected = sp.Point2D(1, 2)
    with sp.evaluate(False):
        point = sp.S('Point2D(Integer(1),Integer(2))')
    assert point == expected
    assert sp.S('Point2D(Integer(1),Integer(2))') == expected
    assert sp.S('Point2D(Integer(1),Integer(2))', evaluate=False) == expected


@pytest.mark.parametrize('dimension', [2, 3, 4])
def test_point_preserves_coordinates_with_evaluation_disabled(dimension):
    value = sp.Float('0.5')
    with sp.evaluate(False):
        expression = sp.Add(1, 2)
        point = sp.Point(value, expression, *([0] * (dimension - 2)))
        unevaluated = sp.Add(1, 2)
    assert point.args == (value, expression) + (sp.S.Zero,) * (dimension - 2)
    assert point.args[0].is_Float
    assert expression.args == (sp.S.One, sp.Integer(2))
    assert unevaluated.args == expression.args


@pytest.mark.parametrize('coordinate', [sp.I, 1 + sp.I, 2 * sp.I])
@pytest.mark.parametrize('evaluation', [True, False])
def test_point_rejects_imaginary_coordinates(coordinate, evaluation):
    with sp.evaluate(evaluation):
        with pytest.raises(ValueError, match='Imaginary coordinates are not permitted'):
            sp.Point2D(1, coordinate)
