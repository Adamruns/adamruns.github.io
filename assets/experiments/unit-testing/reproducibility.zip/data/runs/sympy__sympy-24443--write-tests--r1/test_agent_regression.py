import pytest

from sympy.combinatorics.free_groups import free_group
from sympy.combinatorics.fp_groups import FpGroup
from sympy.combinatorics.homomorphisms import homomorphism
from sympy.combinatorics.named_groups import DihedralGroup


@pytest.mark.parametrize("n", [3, 4, 5])
def test_dihedral_identity_homomorphism(n):
    group = DihedralGroup(n)
    mapping = homomorphism(group, group, group.generators, group.generators)
    elements = list(group.generate_schreier_sims())
    assert all(mapping(element) == element for element in elements)
    assert all(mapping(a*b) == mapping(a)*mapping(b)
               for a in elements for b in elements)


def test_dihedral_invalid_images_are_rejected():
    group = DihedralGroup(3)
    rotation, reflection = group.generators
    with pytest.raises(ValueError, match="do not define a homomorphism"):
        homomorphism(group, group, [rotation, reflection],
                     [reflection, rotation])


def test_finitely_presented_negative_powers():
    free, a, b = free_group("a, b")
    domain = FpGroup(free, [a**3, b**2, b*a*b**-1*a])
    group = DihedralGroup(3)
    rotation, reflection = group.generators
    mapping = homomorphism(domain, group, [a, b], [rotation, reflection])
    assert mapping(a**-2*b*a**-1) == rotation**-2*reflection*rotation**-1
