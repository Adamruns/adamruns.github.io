import pytest
import sympy as sp


def test_sympify_point_with_evaluation_disabled():
    source = 'Point2D(Integer(1),Integer(2))'
    expected = sp.Point2D(1, 2)
    assert sp.S(source) == expected
    assert sp.S(source, evaluate=False) == expected
    with sp.evaluate(False):
        point = sp.S(source)
    assert point == expected


@pytest.mark.parametrize('dimension', [2, 3, 4])
def test_point_preserves_coordinates_with_evaluation_disabled(dimension):
    with sp.evaluate(False):
        coordinate = sp.Add(1, 2)
        coords = (coordinate, sp.Float('0.5')) + (sp.S.Zero,) * (dimension - 2)
        point = sp.Point(*coords)
        # Validation must restore the surrounding evaluation setting.
        assert sp.Add(1, 2).args == (sp.S.One, sp.Integer(2))
    assert point.args == coords
    assert point.args[0].args == (sp.S.One, sp.Integer(2))
    assert point.args[1].is_Float


@pytest.mark.parametrize('coordinate', [sp.I, 1 + sp.I, 2 * sp.I])
@pytest.mark.parametrize('evaluation', [True, False])
def test_point_rejects_imaginary_coordinates(coordinate, evaluation):
    with sp.evaluate(evaluation):
        with pytest.raises(ValueError, match='Imaginary coordinates are not permitted'):
            sp.Point(1, coordinate)
