import pytest

from sympy import Matrix, zeros
from sympy.matrices.normalforms import hermite_normal_form


def test_row_style_hermite_normal_form_preserves_independent_rows():
    original = Matrix([[5, 8, 12], [0, 0, 1]])
    # Reversing both axes is equivalent to np.flip, without requiring NumPy.
    flipped = original[::-1, ::-1]
    result = hermite_normal_form(flipped.T).T[::-1, ::-1]
    assert result == Matrix([[5, 8, 0], [0, 0, 1]])
    assert result.rank() == original.rank()


@pytest.mark.parametrize("matrix, expected", [
    (Matrix([[2, 7], [0, 0], [0, 0]]), Matrix([[1], [0], [0]])),
    (Matrix([[2, 0], [0, 0], [0, 3], [0, 0]]),
     Matrix([[2, 0], [0, 0], [0, 3], [0, 0]])),
    (Matrix([[6], [0], [0]]), Matrix([[6], [0], [0]])),
    (Matrix([[7], [2]]), Matrix([[7], [2]])),
    (zeros(3, 2), zeros(3, 0)),
    (zeros(3, 0), zeros(3, 0)),
    (zeros(0, 3), zeros(0, 0)),
])
def test_hermite_normal_form_handles_missing_pivots(matrix, expected):
    assert hermite_normal_form(matrix) == expected
    assert hermite_normal_form(matrix, D=1, check_rank=True) == expected
