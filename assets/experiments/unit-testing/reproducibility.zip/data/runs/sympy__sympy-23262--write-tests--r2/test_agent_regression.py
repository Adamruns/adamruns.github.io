import inspect

import pytest

from sympy import lambdify, symbols
from sympy.utilities.lambdify import lambdastr


def test_lambdify_singleton_tuple_source_and_result():
    function = lambdify([], (1,))
    assert function() == (1,)
    assert 'return (1,)' in inspect.getsource(function)


@pytest.mark.parametrize('expression, expected', [
    ((), ()),
    ((1,), (1,)),
    ((1, 2), (1, 2)),
    ([1], [1]),
    (((1,),), ((1,),)),
    ([(1,), (), (1, 2)], [(1,), (), (1, 2)]),
    (([1],), ([1],)),
])
def test_generated_container_shapes(expression, expected):
    assert lambdify([], expression, modules='math')() == expected
    assert eval(lambdastr([], expression))() == expected


def test_lambdify_symbolic_singleton_tuple():
    x = symbols('x')
    function = lambdify(x, (x + 1,), modules='math')
    assert function(2) == (3,)
