import pytest

from sympy import Mul, Pow, S, simplify, symbols, sympify


def test_nested_fraction_denominator_grouping():
    a, b, c = symbols('a b c')
    # Match the unevaluated structure produced by convert_frac.
    numerator = Mul(a**3 + b, Pow(c, -1, evaluate=False), evaluate=False)
    denominator = Pow(Pow(c, 2, evaluate=False), -1, evaluate=False)
    expression = Mul(numerator, Pow(denominator, -1, evaluate=False), evaluate=False)

    assert str(expression) == '((a**3 + b)/c)/(1/(c**2))'
    assert simplify(sympify(str(expression)) - expression) == 0
    assert expression.subs({a: 2, b: 1, c: 3}).doit() == 27


@pytest.mark.parametrize('numerator', [1, 2])
@pytest.mark.parametrize('exponent', [-1, -2, -S.Half])
def test_unevaluated_fraction_denominator_grouping(numerator, exponent):
    c = symbols('c')
    denominator = Pow(c, exponent, evaluate=False)
    expression = Mul(numerator, Pow(denominator, -1, evaluate=False), evaluate=False)
    assert simplify(sympify(str(expression)) - expression) == 0


def test_latex_nested_fraction():
    pytest.importorskip('antlr4')
    from sympy.parsing.latex import parse_latex

    expression = parse_latex(r'\frac{\frac{a^3+b}{c}}{\frac{1}{c^2}}')
    assert str(expression) == '((a**3 + b)/c)/(1/(c**2))'
    assert simplify(sympify(str(expression)) - expression) == 0
