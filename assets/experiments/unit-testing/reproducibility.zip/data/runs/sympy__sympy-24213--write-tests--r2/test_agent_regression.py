import pytest

from sympy import Rational
from sympy.physics import units
from sympy.physics.units.systems.si import SI


def test_addition_collects_equivalent_dimensions():
    velocity = units.Quantity('agent_regression_velocity')
    acceleration = units.Quantity('agent_regression_acceleration')
    time = units.Quantity('agent_regression_time')
    SI.set_quantity_dimension(velocity, units.velocity)
    SI.set_quantity_scale_factor(velocity, 2 * units.meter / units.second)
    SI.set_quantity_dimension(acceleration, units.acceleration)
    SI.set_quantity_scale_factor(
        acceleration, -9.8 * units.meter / units.second**2)
    SI.set_quantity_dimension(time, units.time)
    SI.set_quantity_scale_factor(time, 5 * units.second)

    factor, dimension = SI._collect_factor_and_dimension(
        acceleration * time + velocity)

    assert float(factor) == pytest.approx(-47)
    assert SI.get_dimension_system().equivalent_dims(dimension, units.velocity)


def test_addition_preserves_matching_dimensions():
    assert SI._collect_factor_and_dimension(units.meter + units.centimeter) == (
        Rational(101, 100), units.length)


def test_addition_rejects_incompatible_dimensions():
    with pytest.raises(ValueError, match='Dimension of'):
        SI._collect_factor_and_dimension(units.meter + units.second)
