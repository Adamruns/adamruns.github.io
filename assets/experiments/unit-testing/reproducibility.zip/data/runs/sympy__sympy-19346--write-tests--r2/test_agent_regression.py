import pytest

from sympy import Integer, Symbol, srepr


x, y = Symbol('x'), Symbol('y')


def test_srepr_dict_prints_keys_and_values():
    assert srepr({x: y}) == "{Symbol('x'): Symbol('y')}"


def test_srepr_set_prints_elements():
    assert srepr({x, y}) in (
        "{Symbol('x'), Symbol('y')}",
        "{Symbol('y'), Symbol('x')}",
    )
    assert srepr({x}) == "{Symbol('x')}"


@pytest.mark.parametrize('expr', [
    {}, set(), {x: y}, {x, y},
    {x: [y, {x, Integer(2)}], 'nested': ({y: x},)},
    {x, 'text', 2, (y,)},
])
def test_srepr_containers_round_trip(expr):
    assert eval(srepr(expr), {'Symbol': Symbol, 'Integer': Integer}) == expr


def test_srepr_existing_container_forms():
    assert srepr({}) == '{}'
    assert srepr(set()) == 'set()'
    assert srepr([x, y]) == "[Symbol('x'), Symbol('y')]"
    assert srepr((x, y)) == "(Symbol('x'), Symbol('y'))"
