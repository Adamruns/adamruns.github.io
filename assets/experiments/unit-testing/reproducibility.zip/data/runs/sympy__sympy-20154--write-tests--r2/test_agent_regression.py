import pytest

from sympy.utilities.iterables import partitions


@pytest.mark.parametrize('size', [False, True])
@pytest.mark.parametrize('n, options, expected', [
    (4, {}, [{4: 1}, {3: 1, 1: 1}, {2: 2}, {2: 1, 1: 2}, {1: 4}]),
    (6, {'k': 2}, [{2: 3}, {2: 2, 1: 2}, {2: 1, 1: 4}, {1: 6}]),
    (6, {'m': 2}, [{6: 1}, {5: 1, 1: 1}, {4: 1, 2: 1}, {3: 2}]),
])
def test_partitions_yields_independent_dictionaries(size, n, options, expected):
    results = list(partitions(n, size=size, **options))
    if size:
        assert results == [(sum(p.values()), p) for p in expected]
        results = [p for _, p in results]
    assert results == expected
    assert len({id(p) for p in results}) == len(results)


@pytest.mark.parametrize('size', [False, True])
def test_mutating_partition_does_not_change_iteration(size):
    iterator = partitions(4, size=size)
    first = next(iterator)
    first_partition = first[1] if size else first
    first_partition.clear()
    second = next(iterator)
    second_partition = second[1] if size else second
    assert second_partition == {3: 1, 1: 1}
    second_partition.clear()
    remaining = list(iterator)
    expected = [{2: 2}, {2: 1, 1: 2}, {1: 4}]
    if size:
        expected = [(sum(p.values()), p) for p in expected]
    assert remaining == expected
    assert first_partition == {}
    assert second_partition == {}
