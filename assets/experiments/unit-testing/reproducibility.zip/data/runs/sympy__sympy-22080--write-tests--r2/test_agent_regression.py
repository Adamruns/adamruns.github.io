import pytest

from sympy import Mod, lambdify, symbols


x, y, z = symbols('x y z')


@pytest.mark.parametrize('expr', [
    -Mod(x, y),
    2*Mod(x, y),
    z*Mod(x, y),
    (z + 1)*Mod(x, y),
    Mod(x, y)**2,
    2**Mod(x, y),
    1/Mod(x, y),
    Mod(x, Mod(y, z), evaluate=False),
    Mod(Mod(x, y), z, evaluate=False),
])
@pytest.mark.parametrize('values', [(3, 7, 5), (-3, 7, 5), (3, -7, 5)])
def test_lambdify_mod_grouping(expr, values):
    function = lambdify((x, y, z), expr, modules=[])
    expected = expr.subs(dict(zip((x, y, z), values)))
    assert function(*values) == pytest.approx(float(expected))


def test_lambdify_negated_mod_reported_example():
    function = lambdify((x, y), -Mod(x, y), modules=[])
    assert function(3, 7) == -3
