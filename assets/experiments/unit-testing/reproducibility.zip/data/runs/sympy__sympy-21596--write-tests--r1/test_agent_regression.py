from sympy import FiniteSet, I, Lambda, S, Symbol, imageset


def test_imageset_real_intersection_retains_only_real_values():
    n = Symbol('n')
    values = imageset(Lambda(n, n + (n - 1)*(n + 1)*I), S.Integers)

    assert 2 not in values
    real_values = values.intersect(S.Reals)
    assert 2 not in real_values
    assert real_values == FiniteSet(-1, 1)
    assert S.Reals.intersect(values) == FiniteSet(-1, 1)


def test_imageset_real_intersection_respects_base_set():
    n = Symbol('n')
    values = imageset(Lambda(n, n + (n - 1)*(n + 1)*I), S.Naturals)
    assert values.intersect(S.Reals) == FiniteSet(1)


def test_imageset_real_intersection_nonlinear_condition():
    n = Symbol('n')
    values = imageset(Lambda(n, n + (n**2 - S.One/4)*I), S.Rationals)
    real_values = values.intersect(S.Reals)
    assert S.Half in real_values
    assert -S.Half in real_values
    assert 2 not in real_values


def test_imageset_real_intersection_preserves_existing_cases():
    n = Symbol('n', integer=True)
    values = imageset(Lambda(n, n**2), S.Integers)
    assert values.intersect(S.Reals) == values
    assert imageset(Lambda(n, n + I), S.Integers).intersect(S.Reals) == S.EmptySet
    assert imageset(Lambda(n, 1/n), S.Integers).is_subset(S.Reals) is None
