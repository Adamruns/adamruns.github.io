import pytest

from sympy.utilities.iterables import partitions


@pytest.mark.parametrize("size", [False, True])
@pytest.mark.parametrize("n, kwargs, expected", [
    (4, {}, [{4: 1}, {3: 1, 1: 1}, {2: 2}, {2: 1, 1: 2}, {1: 4}]),
    (6, {"k": 2}, [{2: 3}, {2: 2, 1: 2}, {2: 1, 1: 4}, {1: 6}]),
    (6, {"m": 2}, [{6: 1}, {5: 1, 1: 1}, {4: 1, 2: 1}, {3: 2}]),
])
def test_partitions_retains_independent_results(n, kwargs, expected, size):
    results = list(partitions(n, size=size, **kwargs))
    if size:
        assert results == [(sum(p.values()), p) for p in expected]
        results = [p for _, p in results]
    assert results == expected
    assert len({id(p) for p in results}) == len(results)
    results[0].clear()
    assert results[1:] == expected[1:]


@pytest.mark.parametrize("size", [False, True])
def test_mutating_partition_does_not_change_iteration(size):
    iterator = partitions(4, size=size)
    first = next(iterator)
    partition = first[1] if size else first
    partition.clear()
    partition[99] = 7
    remaining = list(iterator)
    expected = [{3: 1, 1: 1}, {2: 2}, {2: 1, 1: 2}, {1: 4}]
    if size:
        expected = [(sum(p.values()), p) for p in expected]
    assert remaining == expected
    assert partition == {99: 7}
