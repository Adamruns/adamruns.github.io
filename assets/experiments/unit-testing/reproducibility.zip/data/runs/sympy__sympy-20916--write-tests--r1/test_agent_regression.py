import pytest

from sympy import Matrix, Symbol, pretty, symbols


@pytest.mark.parametrize("name, expected", [
    ("ω0", "ω₀"),
    ("α12", "α₁₂"),
    ("Ω23", "Ω₂₃"),
    ("ω0^2", "ω²₀"),
    ("ω0_1", "ω₀ ₁"),
    ("omega0", "ω₀"),
    ("w0", "w₀"),
    ("ω_0", "ω₀"),
    ("x1y2", "x1y2"),
    ("123", "123"),
])
def test_unicode_symbol_numeric_subscripts(name, expected):
    assert pretty(Symbol(name), use_unicode=True) == expected
    assert pretty(Symbol(name), use_unicode=False) == name


def test_unicode_greek_subscripts_in_matrix():
    ts = symbols("t0:3")
    matrix = Matrix([[-t * Symbol("ω0") for t in ts]])
    assert pretty(matrix, use_unicode=True) == "[-t₀⋅ω₀  -t₁⋅ω₀  -t₂⋅ω₀]"
