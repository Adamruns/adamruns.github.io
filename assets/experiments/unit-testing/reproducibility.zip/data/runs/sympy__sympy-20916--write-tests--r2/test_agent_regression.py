import pytest

from sympy import Matrix, Symbol, pretty


@pytest.mark.parametrize("name, expected", [
    ("ω0", "ω₀"),
    ("α12", "α₁₂"),
    ("Ω123", "Ω₁₂₃"),
    ("ω0^2", "ω²₀"),
    ("ω0_1", "ω₀ ₁"),
    ("omega0", "ω₀"),
    ("w0", "w₀"),
    ("ω_0", "ω₀"),
    ("ω", "ω"),
    ("0", "0"),
    ("ω+0", "ω+0"),
])
def test_unicode_symbol_numeric_subscripts(name, expected):
    assert pretty(Symbol(name), use_unicode=True) == expected
    assert pretty(Symbol(name), use_unicode=False) == name


def test_greek_numeric_subscripts_in_matrix():
    ts = [Symbol("t%d" % i) for i in range(3)]
    greek = Matrix([[-t * Symbol("ω0") for t in ts]])
    latin = Matrix([[-t * Symbol("w0") for t in ts]])
    assert pretty(greek, use_unicode=True) == pretty(
        latin, use_unicode=True).replace("w", "ω")
