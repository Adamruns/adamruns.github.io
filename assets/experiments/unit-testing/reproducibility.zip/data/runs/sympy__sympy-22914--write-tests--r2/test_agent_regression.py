import pytest

from sympy import Max, Min, pycode, symbols
from sympy.printing.pycode import PythonCodePrinter


@pytest.mark.parametrize('function, builtin', [(Min, min), (Max, max)])
@pytest.mark.parametrize('arity', [2, 3])
def test_python_min_max(function, builtin, arity):
    args = symbols('a b c')[:arity]
    expr = function(*args)
    expected = '{}({})'.format(builtin.__name__, ', '.join(map(str, args)))
    code = pycode(expr)
    assert code == expected
    printer = PythonCodePrinter()
    assert printer.doprint(expr) == expected
    assert not printer.module_imports
    for values in [(-3, 2, 5), (4, -1, -6), (2, 2, 2)]:
        namespace = dict(zip(map(str, args), values))
        assert eval(code, namespace) == builtin(values[:arity])


def test_python_nested_min_max():
    a, b, c = symbols('a b c')
    expr = Min(a + 1, Max(b, c**2))
    code = pycode(expr)
    assert 'min(' in code
    assert 'max(' in code
    for values in [(0, 3, -2), (10, -5, 2), (-4, 0, 0)]:
        namespace = dict(zip(('a', 'b', 'c'), values))
        assert eval(code, namespace) == float(expr.subs(dict(zip((a, b, c), values))))
