from sympy import Integer, Symbol, srepr


def test_srepr_dict_prints_keys_and_values_recursively():
    x, y = Symbol('x'), Symbol('y')
    assert srepr({x: y}) == "{Symbol('x'): Symbol('y')}"
    expr = {x: [y, {y: (x,)}], 'symbols': {x, y}}
    assert eval(srepr(expr), {'Symbol': Symbol}) == expr


def test_srepr_set_prints_elements_recursively():
    x, y = Symbol('x'), Symbol('y')
    assert srepr({x}) == "{Symbol('x')}"
    assert srepr({x, y}) in (
        "{Symbol('x'), Symbol('y')}",
        "{Symbol('y'), Symbol('x')}",
    )
    expr = {x, (y, Integer(2)), 'text', 3}
    assert eval(srepr(expr), {'Symbol': Symbol, 'Integer': Integer}) == expr


def test_srepr_empty_and_existing_containers():
    x = Symbol('x')
    assert srepr({}) == '{}'
    assert srepr(set()) == 'set()'
    assert isinstance(eval(srepr(set())), set)
    assert srepr([x]) == "[Symbol('x')]"
    assert srepr((x,)) == "(Symbol('x'),)"
    assert srepr({'key': 1}) == "{'key': 1}"
