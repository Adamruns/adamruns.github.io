import pytest

from sympy import Mod, Piecewise, cosh, exp, log, sin, sinh, symbols, tanh
from sympy.core.cache import clear_cache


@pytest.mark.parametrize("hyperbolic", [sinh, cosh, tanh])
@pytest.mark.parametrize("outer", [exp, sin, log])
@pytest.mark.parametrize("real_denominator", [True, False])
def test_subs_piecewise_hyperbolic(hyperbolic, outer, real_denominator):
    clear_cache()
    x, y = symbols("x y", real=True)
    z = symbols("z", real=True) if real_denominator else symbols("z")
    piecewise = Piecewise((x, y > x), (y, True))
    expr = outer(hyperbolic(piecewise / z))

    result = expr.subs({1: 1.0})

    assert result == outer(hyperbolic(piecewise / z**1.0))
    assert expr.subs({1: 1.0}) == result


def test_mod_piecewise_remains_evaluable():
    clear_cache()
    x, y = symbols("x y", real=True)
    piecewise = Piecewise((x, y > x), (y, True))

    result = Mod(piecewise, 3)

    assert result == Mod(piecewise, 3, evaluate=False)
    assert result.subs({x: 5, y: 7}) == 2
    assert result.subs({x: 7, y: 5}) == 2
